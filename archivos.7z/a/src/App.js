import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';

// Importa los componentes de las otras páginas que vayas a crear
const Dashboard = () => <div>Página Principal (Dashboard)</div>;
const AdminPanel = () => <div>Panel de Administración</div>;

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Login />} /> {/* Redirige a /login por defecto */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/admin-panel" element={<AdminPanel />} />
        {/* Aquí puedes añadir más rutas para las otras vistas de tu aplicación */}
      </Routes>
    </Router>
  );
}

export default App;
